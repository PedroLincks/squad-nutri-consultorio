# Playbook — VSL (Video Sales Letter) e Roteiros de Vídeo de Vendas

Lendas: Stefan Georgi (RMBC), Jon Benson (inventor do VSL). Pesquisa primeiro — 80% research, 20% escrita.

## Estrutura RMBC (Georgi) — espinha dorsal
1. **Relate** — abra com história/cenário que o prospect viveu. Rapport antes de persuasão.
2. **Mechanism** — o Mecanismo Único de 2 partes: (1) a causa-raiz oculta do problema (por que tudo falhou até agora), (2) a solução específica do produto para essa raiz.
3. **Benefits** — empilhe benefícios com future pacing e emoção.
4. **Close** — ancoragem de preço, garantia, stack de bônus, urgência, CTA.

## VSL em 7 seções (operacional)
1. **Lead/Hook** (0-60s) — pattern interrupt, promessa grande, seleciona o público. Snap Suggestion (Benson): prenda nos primeiros slides.
2. **Problema + Agitação** — magnifique a dor de superfície até a implicação emocional profunda.
3. **Mecanismo** — nomeie e brande o mecanismo. É o que vende em mercado cético (Stage 3+).
4. **Prova** — depoimentos, estudos, demonstração, autoridade. Cada claim sustentado.
5. **Revelação do Produto** — apresente como a aplicação inevitável do mecanismo.
6. **Oferta** — stack de valor, ancoragem de preço, bônus, garantia (reversão de risco).
7. **Fechamento** — 3 escolhas (Benson: comprar e ganhar / não fazer nada / tentar sozinho e falhar), urgência, CTA repetido.

## Técnicas de pacing e PNL (Benson)
- **Reluctant Hero:** o narrador resistiu, duvidou — e cedeu à evidência. Gera rapport.
- **Future pacing:** faça o prospect se ver vivendo o resultado.
- **Open loops:** abra curiosidade cedo, resolva depois.
- Frases declarativas (afirme como fato). Mesmerizar, não entreter.

## Regras
- Linguagem do próprio prospect — não invente jargão.
- Mecanismo nomeado é obrigatório em mercado sofisticado.
- Nada de prova/resultado inventado.
- Entregue com timestamps e **notas de cena** quando for vídeo gravado.

## Entrega padrão
```
PRODUTO / DURAÇÃO ALVO / NÍVEL DE CONSCIÊNCIA / SOFISTICAÇÃO

[SEÇÃO 1 — LEAD] (0:00-1:00)
Narração: ...
Notas de cena/tela: ...

[SEÇÃO 2 — PROBLEMA] ...
...
```
